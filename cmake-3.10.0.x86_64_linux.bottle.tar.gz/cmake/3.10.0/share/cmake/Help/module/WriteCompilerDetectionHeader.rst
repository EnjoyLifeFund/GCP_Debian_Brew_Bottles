.. cmake-module:: ../../Modules/WriteCompilerDetectionHeader.cmake
