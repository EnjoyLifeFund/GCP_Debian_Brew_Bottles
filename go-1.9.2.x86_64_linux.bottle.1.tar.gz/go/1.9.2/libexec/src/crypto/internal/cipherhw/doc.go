// Copyright 2016 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package cipherhw exposes common functions for detecting whether hardware
// support for certain ciphers and authenticators is present.
package cipherhw
