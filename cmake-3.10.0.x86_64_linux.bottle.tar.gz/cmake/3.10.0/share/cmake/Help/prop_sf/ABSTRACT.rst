ABSTRACT
--------

Is this source file an abstract class.

A property on a source file that indicates if the source file
represents a class that is abstract.  This only makes sense for
languages that have a notion of an abstract class and it is only used
by some tools that wrap classes into other languages.
